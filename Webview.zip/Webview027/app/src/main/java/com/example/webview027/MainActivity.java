package com.example.webview027;

import static java.util.Base64.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {

    WebView myWebView = (WebView) findViewById(R.id.webview);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setContentView(myWebView);
        myWebView.loadUrl("http://nmit.ac.in/lms");
        
        String unencodedHtml = "<html> <body> '%23' is the percent code for '#' </body> </html>";
        String encodedHtml = Base64.encodeToString(unencodedHtml.getBytes(), Base64.NO_PADDING);

        myWebView.loadData(encodedHtml, "text/html", "base64");
    }
}